﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio09
{
    internal class Livro
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public double Valor { get; set; }

        public Livro(string titulo, string autor, double valor)
        {
            Titulo = titulo;
            Autor = autor;
            Valor = valor;
        }
        public override string ToString()
        {
            return $"Título: {Titulo}\nAutor: {Autor}\nValor: R$ {Valor:F2}";
        }
    }
}
