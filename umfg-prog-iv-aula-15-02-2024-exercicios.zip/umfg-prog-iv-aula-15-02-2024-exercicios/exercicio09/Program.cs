﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace exercicio09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Livro livroCadastrado = CadastrarLivro();

            Console.WriteLine("\nLivro cadastrado:\n");
            Console.WriteLine(livroCadastrado.ToString());
        }

        static Livro CadastrarLivro()
        {
            Console.WriteLine("Informe os dados do livro:\n");

            Console.Write("Título: ");
            string titulo = Console.ReadLine();

            Console.Write("Autor: ");
            string autor = Console.ReadLine();

            Console.Write("Valor: R$ ");
            double valor = 0;

            while (!double.TryParse(Console.ReadLine(), out valor))
            {
                Console.WriteLine("Valor inválido. Por favor, insira um valor válido.");
                Console.Write("Valor: R$ ");
            }

            return new Livro(titulo, autor, valor);
        }
    }
}
