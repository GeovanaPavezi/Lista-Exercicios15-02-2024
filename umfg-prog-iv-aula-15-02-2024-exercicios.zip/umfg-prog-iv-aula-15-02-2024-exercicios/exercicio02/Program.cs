﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double taxaCambio = 5.22;
            double valorUSD;

            Console.WriteLine("Conversor de Dólar para Real");
            Console.Write("Digite o valor em Dólar: ");

            if (double.TryParse(Console.ReadLine(), out valorUSD))
            {
                double valorBRL = valorUSD * taxaCambio;

                Console.WriteLine($"{valorUSD}$ equivale(m) a {valorBRL}R$");
            }
            else
            {
                Console.WriteLine("Insira um valor válido");
            }
        }
    }
}
