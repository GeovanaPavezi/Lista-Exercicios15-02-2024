﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string vogais = "AEIOUaeiou";
            int contagem = 0;

            Console.WriteLine("Informe seu nome: ");
            string nome = Console.ReadLine();

            if (nome != null)
            {
                foreach (char caractere in nome)
                {
                    if (vogais.IndexOf(caractere) >= 0)
                    {
                        contagem++;
                    }
                }
                Console.WriteLine("A quantidade de vogais é: " + contagem);
            }
        }

    }
}
