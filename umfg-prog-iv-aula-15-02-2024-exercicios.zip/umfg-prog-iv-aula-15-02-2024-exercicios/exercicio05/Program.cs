﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Calculadora\n");
                Console.WriteLine("Escolha uma operação:");
                Console.WriteLine("1 - Soma");
                Console.WriteLine("2 - Subtração");
                Console.WriteLine("3 - Multiplicação");
                Console.WriteLine("4 - Divisão");
                Console.WriteLine("5 - Resto da Divisão");
                Console.WriteLine("0 - Sair");

                Console.Write("Digite o número da operação desejada: ");
                if (!int.TryParse(Console.ReadLine(), out int opcao))
                {
                    Console.WriteLine("Insira um número válido para a operação");
                    continue;
                }

                if (opcao == 0)
                    break;

                Console.WriteLine("Informe o primeiro número desejado: ");
                if (!float.TryParse(Console.ReadLine(), out float num1))
                {
                    Console.WriteLine("Insira um número válido para o primeiro número");
                    continue;
                }

                Console.WriteLine("Informe o segundo número desejado: ");
                if (!float.TryParse(Console.ReadLine(), out float num2))
                {
                    Console.WriteLine("Insira um número válido para o segundo número");
                    continue;
                }

                float resultado = 0;

                switch (opcao)
                {
                    case 1:
                        resultado = num1 + num2;
                        break;
                    case 2:
                        resultado = num1 - num2;
                        break;
                    case 3:
                        resultado = num1 * num2;
                        break;
                    case 4:
                        if (num2 != 0)
                            resultado = num1 / num2;
                        else
                            Console.WriteLine("Divisão por zero");
                        break;
                    case 5:
                        if (num2 != 0)
                            resultado = num1 % num2;
                        else
                            Console.WriteLine("Divisão por zero");
                        break;
                    default:
                        Console.WriteLine("Opção inválida");
                        break;
                }

                Console.WriteLine($"Resultado: {resultado}");
                Console.WriteLine();
            }
        }
    }
}
