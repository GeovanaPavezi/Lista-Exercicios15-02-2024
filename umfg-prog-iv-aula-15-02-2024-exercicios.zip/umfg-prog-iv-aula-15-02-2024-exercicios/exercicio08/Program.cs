﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Informe seu nome: ");
            string nome = Console.ReadLine();

            Console.WriteLine("Informe sua data de nascimento: ");
            string dataNascimento = Console.ReadLine();

            if (!DateTime.TryParse(dataNascimento, out DateTime dataNascComp))
                return;

            var idade = DateTime.Now.Year - dataNascComp.Year;

            if (dataNascComp > DateTime.Now.AddYears(-idade))
                idade--;

            if (idade < 20)
            {
                Console.WriteLine("Nome: " + nome + ", Idade: " + idade + " anos, Faixa etária: Jovem");
            }
            else if (idade >= 20 && idade <= 59)
            {
                Console.WriteLine("Nome: " + nome + ", Idade: " + idade + " anos, Faixa etária: Adulto");
            }
            else 
            {
                Console.WriteLine("Nome: " + nome + ", Idade: " + idade + " anos, Faixa etária: Idoso");
            }
        }
    }
}
