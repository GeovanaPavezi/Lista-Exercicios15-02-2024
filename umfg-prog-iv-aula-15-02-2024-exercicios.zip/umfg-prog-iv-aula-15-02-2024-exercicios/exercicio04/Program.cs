﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Informe seu ano de nascimento: ");

            if (int.TryParse(Console.ReadLine(), out int anoNascimento))
            {
                int anoAtual = DateTime.Now.Year;

                int idade = anoAtual - anoNascimento;

                Console.WriteLine($"Sua idade é: {idade} anos");
            }
            else
            {
                Console.WriteLine("Insira um ano de nascimento válido");
            }
        }
    }
}
