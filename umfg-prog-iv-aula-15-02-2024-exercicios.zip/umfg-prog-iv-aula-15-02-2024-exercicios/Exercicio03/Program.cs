﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Informe a distância total em KM percorrida: ");
                double distanciaTotal = Convert.ToDouble(Console.ReadLine());

                Console.Write("Informe o gasto de combustível em Litros: ");
                double gastoCombustivel = Convert.ToDouble(Console.ReadLine());

                if (distanciaTotal <= 0 || gastoCombustivel <= 0)
                {
                    Console.WriteLine("Informe valores válidos para a distância e o gasto de combustível");
                }
                else
                {
                    double mediaConsumo = distanciaTotal / gastoCombustivel;
                    Console.WriteLine($"A média de consumo do automóvel é: {mediaConsumo:F2} KM/L");
                }
            } 
            catch (FormatException)
            {
                Console.WriteLine("Informe valores numéricos válidos");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro: {ex.Message}");
            }
        }
    }
}
