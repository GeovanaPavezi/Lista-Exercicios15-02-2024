﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio09
{
    internal struct Livro
    {
        public string titulo;
        public string autor;
        public double valor;

        public override string ToString()
        {
            return $"Titulo: {titulo}\nAutor: {autor}\nValor: {valor:C}";
        }

        static void Main(string[] args)
        {

            Livro livro = new Livro();

            Console.WriteLine("Cadastre um livro:\n");

            Console.WriteLine("Entre com o título do livro: ");
            livro.titulo = Console.ReadLine();

            Console.WriteLine("Entre com o autor do livro: ");
            livro.autor = Console.ReadLine();

            Console.WriteLine("Entre com o valor do livro: ");
            double.TryParse(Console.ReadLine(), out livro.valor);


            Console.WriteLine("\nDetalhes do Livro Cadastrado:\n\n" + livro.ToString());
        }
    }
}
