﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace umfg_prog_iv_aula_15_02_2024_exercicios
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double taxaCambio = 0.193259;
            double valorBRL;

            Console.WriteLine("Conversor de Real para Dólar");
            Console.Write("Digite o valor em Real: ");


            if (double.TryParse(Console.ReadLine(), out valorBRL))
            {
                double valorUSD = valorBRL * taxaCambio;

                Console.WriteLine($"{valorBRL}R$ equivale(m) a {valorUSD}$");
            }
            else
            {
                Console.WriteLine("Insira um valor válido");
            }
        }
    }
}