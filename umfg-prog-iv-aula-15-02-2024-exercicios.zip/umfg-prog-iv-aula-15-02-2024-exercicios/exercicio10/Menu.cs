﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio10
{
    internal class Menu
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Menu\n");
                Console.WriteLine("Escolha uma das opções:");
                Console.WriteLine("1 - Cadastro de Aluno");
                Console.WriteLine("2 - Cadastro de Notas");
                Console.WriteLine("3 - Cadastro Total de Faltas");
                Console.WriteLine("4 - Relação de Alunos, Notas, Média, Faltas e Situação");
                Console.WriteLine("0 - Sair");

                Console.Write("Digite o número da opção desejada: ");
                if (!int.TryParse(Console.ReadLine(), out int opcao))
                {
                    Console.WriteLine("Opção inválida");
                    continue;
                }

                if (opcao == 0)
                    break;
            }
        }
    }
}
