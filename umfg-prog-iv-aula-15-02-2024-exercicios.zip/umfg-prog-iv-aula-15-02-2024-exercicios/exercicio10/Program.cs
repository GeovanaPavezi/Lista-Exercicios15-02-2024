﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Escola escola = new Escola();

            int opcao;

            do
            {
                Console.WriteLine("MENU:");
                Console.WriteLine("1 - Cadastro de Alunos");
                Console.WriteLine("2 - Cadastro de Notas");
                Console.WriteLine("3 - Cadastro Total de Faltas");
                Console.WriteLine("4 - Relação de Alunos, Notas, Média, Faltas e Situação");
                Console.WriteLine("0 - Sair");
                Console.Write("Escolha uma opção: ");

                if (int.TryParse(Console.ReadLine(), out opcao))
                {
                    switch (opcao)
                    {
                        case 1:
                            escola.CadastrarAluno();
                            break;
                        case 2:
                            escola.CadastrarNotas();
                            break;
                        case 3:
                            escola.CadastrarFaltas();
                            break;
                        case 4:
                            escola.ExibirRelatorio();
                            break;
                        case 0:
                            Console.WriteLine("Saindo do programa");
                            break;
                        default:
                            Console.WriteLine("Opção inválida. Tente novamente");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Opção inválida. Tente novamente");
                }

            } while (opcao != 0);
        }
    }

    class Aluno
    {
        public string Nome { get; set; }
        public int RA { get; set; }
        public double NotaProva { get; set; }
        public double NotaTrabalho { get; set; }
        public int TotalFaltas { get; set; }
    }

    class Escola
    {
        private List<Aluno> alunos = new List<Aluno>();

        public void CadastrarAluno()
        {
            Aluno aluno = new Aluno();

            Console.Write("Nome do aluno: ");
            aluno.Nome = Console.ReadLine();

            Console.Write("RA do aluno: ");
            if (int.TryParse(Console.ReadLine(), out int ra))
            {
                aluno.RA = ra;
                alunos.Add(aluno);
                Console.WriteLine("Aluno cadastrado com sucesso!\n");
            }
            else
            {
                Console.WriteLine("RA inválido. O cadastro não foi realizado.\n");
            }
        }

        public void CadastrarNotas()
        {
            Console.Write("Informe o RA do aluno: ");
            if (int.TryParse(Console.ReadLine(), out int ra))
            {
                Aluno aluno = alunos.Find(a => a.RA == ra);

                if (aluno != null)
                {
                    Console.Write("Nota da prova (máximo 10): ");
                    if (double.TryParse(Console.ReadLine(), out double notaProva) && notaProva >= 0 && notaProva <= 10)
                    {
                        aluno.NotaProva = notaProva;

                        Console.Write("Nota do trabalho (máximo 10): ");
                        if (double.TryParse(Console.ReadLine(), out double notaTrabalho) && notaTrabalho >= 0 && notaTrabalho <= 10)
                        {
                            aluno.NotaTrabalho = notaTrabalho;
                            Console.WriteLine("Notas cadastradas com sucesso!\n");
                        }
                        else
                        {
                            Console.WriteLine("Nota inválida. O cadastro não foi realizado.\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Nota inválida. O cadastro não foi realizado.\n");
                    }
                }
                else
                {
                    Console.WriteLine("Aluno não encontrado.\n");
                }
            }
            else
            {
                Console.WriteLine("RA inválido. Tente novamente.\n");
            }
        }

        public void CadastrarFaltas()
        {
            Console.Write("Informe o RA do aluno: ");
            if (int.TryParse(Console.ReadLine(), out int ra))
            {
                Aluno aluno = alunos.Find(a => a.RA == ra);

                if (aluno != null)
                {
                    Console.Write("Total de faltas: ");
                    if (int.TryParse(Console.ReadLine(), out int totalFaltas) && totalFaltas >= 0)
                    {
                        aluno.TotalFaltas = totalFaltas;
                        Console.WriteLine("Faltas cadastradas com sucesso!\n");
                    }
                    else
                    {
                        Console.WriteLine("Número de faltas inválido. O cadastro não foi realizado.\n");
                    }
                }
                else
                {
                    Console.WriteLine("Aluno não encontrado.\n");
                }
            }
            else
            {
                Console.WriteLine("RA inválido. Tente novamente.\n");
            }
        }

        public void ExibirRelatorio()
        {
            if (alunos.Count > 0)
            {
                Console.WriteLine("Relatório de Alunos:");

                foreach (var aluno in alunos)
                {
                    double media = (aluno.NotaProva * 7 + aluno.NotaTrabalho * 3) / 10;
                    double percentualFrequencia = ((25 - aluno.TotalFaltas) / 25.0) * 100;

                    Console.WriteLine($"Nome: {aluno.Nome}");
                    Console.WriteLine($"RA: {aluno.RA}");
                    Console.WriteLine($"Nota da prova: {aluno.NotaProva}");
                    Console.WriteLine($"Nota do trabalho: {aluno.NotaTrabalho}");
                    Console.WriteLine($"Média: {media}");
                    Console.WriteLine($"Total de faltas: {aluno.TotalFaltas}");
                    Console.WriteLine($"Percentual de frequência: {percentualFrequencia}%");

                    if (media >= 7 && percentualFrequencia >= 75)
                    {
                        Console.WriteLine("Situação: APROVADO\n");
                    }
                    else
                    {
                        Console.WriteLine("Situação: REPROVADO\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("Nenhum aluno cadastrado.\n");
            }
        }
    }
}

